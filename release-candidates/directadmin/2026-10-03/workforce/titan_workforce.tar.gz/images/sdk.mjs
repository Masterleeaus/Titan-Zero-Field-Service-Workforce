// packages/titan-platform/src/directadmin-session-bridge.ts
var COOKIE = "__Host-titan-da-session";
var bridgeFailureMarker = /* @__PURE__ */ Symbol.for("titan.directadmin.bridge.failure.v1");
function bridgeError(kind, message) {
  const error = new Error(message);
  Object.defineProperty(error, bridgeFailureMarker, { value: kind });
  return error;
}
function directAdminBridgeFailureKind(error) {
  try {
    if (!(error instanceof Error)) return void 0;
    const descriptor = Object.getOwnPropertyDescriptor(error, bridgeFailureMarker);
    return descriptor && "value" in descriptor && [
      "request-rejected",
      "session-rejected",
      "unavailable",
      "session-rejected-clear-cookie",
      "unavailable-clear-cookie",
      "session-binding-mismatch"
    ].includes(descriptor.value) ? descriptor.value : void 0;
  } catch {
    return void 0;
  }
}
var fail = () => {
  throw bridgeError("session-rejected", "directadmin-session-rejected");
};
var failAndClear = () => {
  throw bridgeError("session-rejected-clear-cookie", "directadmin-session-rejected");
};
var rejectRequest = () => {
  throw bridgeError("request-rejected", "directadmin-session-rejected-request");
};
var unavailable = () => {
  throw bridgeError("unavailable", "directadmin-service-unavailable");
};
var unavailableAndClear = () => {
  throw bridgeError("unavailable-clear-cookie", "directadmin-service-unavailable");
};
var bindingMismatch = () => {
  throw bridgeError("session-binding-mismatch", "directadmin-session-binding-mismatch");
};
function safeErrorMessage(error) {
  try {
    if (!(error instanceof Error)) return void 0;
    const message = Object.getOwnPropertyDescriptor(error, "message");
    return message && "value" in message && typeof message.value === "string" ? message.value : void 0;
  } catch {
    return void 0;
  }
}
function normalizeAuthenticationFailure(error) {
  const message = safeErrorMessage(error);
  if (message === "directadmin-session-rejected-request") return rejectRequest();
  if (message === "directadmin-session-rejected" || message === "authentication-denied") return fail();
  if (message === "identity-registry-unavailable" || message === "directadmin-service-unavailable") return unavailable();
  return unavailable();
}
async function normalizePostAuthenticationFailure(_error, verifyCurrent) {
  try {
    await verifyCurrent();
  } catch (verificationError) {
    return normalizeAuthenticationFailure(verificationError);
  }
  return unavailable();
}
var id = (v) => typeof v === "string" && v.length > 0 && v.length <= 1024 && !/[\u0000-\u0020\u007f]/u.test(v);
function encode(value) {
  return btoa(String.fromCharCode(...value)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
async function csrfDigest(value) {
  return encode(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))));
}
function validBootstrapInput(value) {
  try {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const keys = Reflect.ownKeys(value);
    if (keys.length !== 4 || keys.some((key) => typeof key !== "string" || !["login_assertion", "company_id", "device_id", "csrf_token"].includes(key))) return false;
    const fields = Object.getOwnPropertyDescriptors(value);
    const values = Object.fromEntries(keys.map((key) => {
      const descriptor = fields[key];
      return [key, descriptor && "value" in descriptor ? descriptor.value : void 0];
    }));
    return typeof values.login_assertion === "string" && values.login_assertion.length > 0 && values.login_assertion.length <= 16384 && id(values.company_id) && id(values.device_id) && typeof values.csrf_token === "string" && /^[A-Za-z0-9_-]{43,128}$/.test(values.csrf_token);
  } catch {
    return false;
  }
}
async function directAdminContextRevisionAssertion(revision) {
  if (typeof revision !== "string" || revision.length === 0 || revision.length > 4096) {
    throw new Error("directadmin-context-revision-invalid");
  }
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(revision));
  return `ctx1_${encode(new Uint8Array(digest))}`;
}
async function matchesDirectAdminContextRevision(assertion, revision) {
  if (assertion === revision) return true;
  if (typeof assertion !== "string" || !/^ctx1_[A-Za-z0-9_-]{43}$/.test(assertion)) return false;
  return assertion === await directAdminContextRevisionAssertion(revision);
}
function cookie(request) {
  const values = (request.headers.get("cookie") ?? "").split(";").map((v) => v.trim()).filter((v) => v.startsWith(`${COOKIE}=`));
  if (values.length !== 1) return fail();
  const credential = values[0].slice(COOKIE.length + 1);
  if (!credential || credential.length > 16384) return fail();
  return credential;
}
function bootstrapCookies(request) {
  const header = request.headers.get("cookie");
  if (header === null || header === "") return Object.freeze({ directAdminCookie: null });
  if (header.length > 16384 || /[\r\n\u0000]/.test(header)) return rejectRequest();
  const passThrough = [];
  let titanCredential;
  for (const raw of header.split(";")) {
    const part = raw.trim();
    if (!part) continue;
    const separator = part.indexOf("=");
    if (separator <= 0) return rejectRequest();
    const name = part.slice(0, separator).trim();
    if (name === COOKIE) {
      if (titanCredential !== void 0) return rejectRequest();
      titanCredential = part.slice(separator + 1);
      if (!titanCredential || titanCredential.length > 16384) return rejectRequest();
    } else passThrough.push(part);
  }
  const directAdminCookie = passThrough.length ? passThrough.join("; ") : null;
  if (directAdminCookie && directAdminCookie.length > 8192) return rejectRequest();
  return Object.freeze({ ...titanCredential === void 0 ? {} : { titanCredential }, directAdminCookie });
}
function usableDirectAdminSession(authenticated, provider, audience, nodeId) {
  const binding = authenticated.directadmin;
  return authenticated.provider === provider && id(authenticated.subject) && authenticated.context.audience === audience && binding?.node_id === nodeId && /^[A-Za-z0-9_-]{43}$/.test(binding.csrf_sha256) && ["admin", "reseller", "user"].includes(binding.da_role) && id(authenticated.context.session_id) && id(authenticated.context.actor_id) && id(authenticated.context.company_id) && id(authenticated.context.device_id) && typeof authenticated.context.context_revision === "string" && authenticated.context.context_revision.length > 0 && authenticated.context.context_revision.length <= 4096 && Number.isSafeInteger(authenticated.context.session_revision) && authenticated.context.session_revision > 0 && Number.isFinite(Date.parse(authenticated.context.expires_at));
}
function bootstrapFailureFor(error, staleCookie) {
  const message = safeErrorMessage(error);
  if (message === "directadmin-session-rejected-request") return rejectRequest();
  if (message === "directadmin-session-rejected" || message === "authentication-denied") {
    return staleCookie ? failAndClear() : fail();
  }
  return staleCookie ? unavailableAndClear() : unavailable();
}
async function hasEmptyBody(request) {
  const reader = request.body?.getReader();
  if (!reader) return true;
  let timedOut = false;
  const deadline = setTimeout(() => {
    timedOut = true;
    void reader.cancel().catch(() => {
    });
  }, 5e3);
  let empty = false;
  try {
    const first = await reader.read();
    empty = first.done && !timedOut;
  } catch {
  } finally {
    clearTimeout(deadline);
    if (!empty) void reader.cancel().catch(() => {
    });
  }
  return empty;
}
var DirectAdminSessionBridge = class {
  #config;
  #provider;
  constructor(config) {
    const origin = new URL(config.origin);
    if (origin.protocol !== "https:" || origin.origin !== config.origin || !id(config.audience) || !id(config.node_id) || !["issue", "authenticate", "switchCompany", "revoke", "exchangeWorkforceZero"].every((method) => typeof config.sessions?.[method] === "function")) fail();
    const provider = `directadmin:${origin.origin}`;
    this.#provider = provider;
    this.#config = Object.freeze({ ...config });
  }
  /**
   * Exchange a trusted DirectAdmin login assertion for a browser session
   * cookie. On document reload the same flow renews a canonically current
   * session after the host reauthenticates its DirectAdmin cookie. The assertion,
   * selected company/device expectations and CSRF nonce must come from the
   * authenticated DirectAdmin adapter, never from caller identity headers or
   * a browser-supplied role/session ID. #302 verifies the assertion and resolves
   * the existing actor, company membership, device and current revisions.
   *
   * The trusted provider consumes the one-time pre-authentication CSRF nonce,
   * authenticates the DirectAdmin session proof and returns a signed assertion,
   * canonical selected company/device and a fresh CSRF token bound into that
   * assertion. The browser supplies no identity fields. The returned credential
   * is only in the Secure HttpOnly cookie; the CSRF token is returned separately
   * for the browser client. No identity store or assertion signer lives here.
   * A reload nonce is never treated as the prior session's CSRF token. The
   * prior Titan cookie is authenticated only by #302, then stripped before the
   * remaining DirectAdmin cookies reach the host provider. Outages preserve a
   * still-current prior session; successful renewal rotates it only after the
   * replacement is reauthenticated and bound to the same provider, subject,
   * actor and device.
   */
  async bootstrapBrowserSession(request, resolveInput) {
    let url;
    try {
      url = new URL(request.url);
    } catch {
      return rejectRequest();
    }
    const csrfNonce = request.headers.get("x-titan-da-bootstrap-csrf") ?? "";
    const contentLength = request.headers.get("content-length");
    if (request.method !== "POST" || url.origin !== this.#config.origin || url.pathname !== "/v1/directadmin/bootstrap" || url.search || url.hash || request.headers.get("origin") !== this.#config.origin || request.headers.get("sec-fetch-site") !== "same-origin" || request.headers.has("content-encoding") || contentLength !== null && !/^0+$/.test(contentLength) || !/^[A-Za-z0-9_-]{43,128}$/.test(csrfNonce) || typeof resolveInput !== "function") {
      return rejectRequest();
    }
    if (!await hasEmptyBody(request)) return rejectRequest();
    const cookies = bootstrapCookies(request);
    let previous;
    let staleCookie = false;
    if (cookies.titanCredential !== void 0) {
      let current;
      try {
        current = await this.#config.sessions.authenticate(cookies.titanCredential);
      } catch (error) {
        const message = safeErrorMessage(error);
        if (message === "identity-registry-unavailable" || message === "directadmin-service-unavailable") return unavailable();
        if (message === "authentication-denied" || message === "directadmin-session-rejected") staleCookie = true;
        else return unavailable();
      }
      if (!staleCookie) {
        if (!usableDirectAdminSession(current, this.#provider, this.#config.audience, this.#config.node_id)) return bindingMismatch();
        previous = current;
      }
    }
    const proof = Object.freeze({
      origin: request.headers.get("origin"),
      cookie: cookies.directAdminCookie,
      authorization: null,
      csrf_nonce: csrfNonce
    });
    let input;
    try {
      input = await resolveInput(proof);
    } catch (error) {
      return bootstrapFailureFor(error, staleCookie);
    }
    if (!validBootstrapInput(input)) return rejectRequest();
    const expected = Object.freeze({ company_id: input.company_id, device_id: input.device_id });
    let csrfHash;
    try {
      csrfHash = await csrfDigest(input.csrf_token);
    } catch {
      return staleCookie ? unavailableAndClear() : unavailable();
    }
    let issued;
    try {
      issued = await this.#config.sessions.issue(input.login_assertion, expected);
    } catch (error) {
      return bootstrapFailureFor(error, staleCookie);
    }
    let authenticated;
    try {
      authenticated = await this.#config.sessions.authenticate(issued.credential, expected);
    } catch (error) {
      return bootstrapFailureFor(error, staleCookie);
    }
    const context = authenticated.context;
    const issuedContext = issued.context;
    const binding = authenticated.directadmin;
    if (authenticated.provider !== this.#provider || !id(authenticated.subject) || context.audience !== this.#config.audience || !id(context.session_id) || !id(context.actor_id) || !id(context.company_id) || !id(context.device_id) || typeof context.context_revision !== "string" || !context.context_revision || context.context_revision.length > 4096 || !Number.isSafeInteger(context.session_revision) || context.session_revision < 1 || context.company_id !== input.company_id || context.device_id !== input.device_id || !binding || binding.node_id !== this.#config.node_id || binding.csrf_sha256 !== csrfHash || !["admin", "reseller", "user"].includes(binding.da_role) || context.session_id !== issuedContext.session_id || context.actor_id !== issuedContext.actor_id || context.company_id !== issuedContext.company_id || context.device_id !== issuedContext.device_id || context.session_revision !== issuedContext.session_revision || context.context_revision !== issuedContext.context_revision) {
      try {
        await this.#config.sessions.revoke(issued.credential, expected);
      } catch {
        return staleCookie ? unavailableAndClear() : unavailable();
      }
      return staleCookie ? failAndClear() : fail();
    }
    if (previous && (authenticated.provider !== previous.provider || authenticated.subject !== previous.subject || context.actor_id !== previous.context.actor_id || context.device_id !== previous.context.device_id || context.session_id === previous.context.session_id)) {
      try {
        await this.#config.sessions.revoke(issued.credential, expected);
      } catch {
        return unavailable();
      }
      return bindingMismatch();
    }
    const expiresAt = Math.min(Date.parse(context.expires_at), Date.parse(authenticated.credential_expires_at));
    const seconds = Math.min(300, Math.floor((expiresAt - Date.now()) / 1e3));
    if (!Number.isFinite(seconds) || seconds <= 0 || /[;\r\n]/.test(issued.credential)) {
      try {
        await this.#config.sessions.revoke(issued.credential, expected);
      } catch {
        return staleCookie ? unavailableAndClear() : unavailable();
      }
      return staleCookie ? failAndClear() : fail();
    }
    if (previous && cookies.titanCredential !== void 0) {
      try {
        await this.#config.sessions.revoke(cookies.titanCredential, {
          company_id: previous.context.company_id,
          device_id: previous.context.device_id,
          actor_id: previous.context.actor_id,
          context_revision: previous.context.context_revision
        });
      } catch (error) {
        const message = safeErrorMessage(error);
        if (message !== "authentication-denied" && message !== "directadmin-session-rejected") return unavailable();
      }
    }
    return Object.freeze({
      set_cookie: `${COOKIE}=${issued.credential}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${seconds}`,
      csrf_token: input.csrf_token
    });
  }
  async authenticate(request) {
    try {
      const url = new URL(request.url);
      const origin = request.headers.get("origin");
      let refererSameOrigin = false;
      if (origin === null && request.method === "GET") {
        try {
          refererSameOrigin = new URL(request.headers.get("referer") ?? "").origin === this.#config.origin;
        } catch {
        }
      }
      const sameOrigin = origin === this.#config.origin || refererSameOrigin;
      if (url.origin !== this.#config.origin || request.headers.get("sec-fetch-site") !== "same-origin" || !sameOrigin || !["GET", "POST"].includes(request.method)) return rejectRequest();
      const credential = cookie(request);
      const csrf = request.headers.get("x-titan-csrf") ?? "";
      if (!/^[A-Za-z0-9_-]{43,128}$/.test(csrf)) return rejectRequest();
      const csrfHash = await csrfDigest(csrf);
      const check = (authenticated) => {
        if (authenticated.provider !== this.#provider || authenticated.context.audience !== this.#config.audience || authenticated.directadmin?.node_id !== this.#config.node_id || authenticated.directadmin.csrf_sha256 !== csrfHash) return fail();
        return authenticated;
      };
      const initial = check(await this.#config.sessions.authenticate(credential));
      const expected = Object.freeze({
        company_id: initial.context.company_id,
        device_id: initial.context.device_id,
        actor_id: initial.context.actor_id,
        context_revision: initial.context.context_revision
      });
      const authenticateCurrent = async () => check(await this.#config.sessions.authenticate(credential, expected));
      const project = ({ context: current, directadmin }) => Object.freeze({
        schema: "titan.directadmin.session/v1",
        actor_id: current.actor_id,
        company_id: current.company_id,
        company_ids: Object.freeze([current.company_id]),
        context_revision: current.context_revision,
        session_revision: current.session_revision,
        expires_at: Date.parse(current.expires_at),
        da_role: directadmin.da_role,
        authority: "not-carried"
      });
      const revalidate = async () => {
        try {
          return project(await authenticateCurrent());
        } catch (error) {
          return normalizeAuthenticationFailure(error);
        }
      };
      const withWorkforceZeroSession = async (consume) => {
        if (request.method !== "POST" || typeof consume !== "function") return fail();
        let source;
        let exchanged;
        try {
          source = await authenticateCurrent();
        } catch (error) {
          return normalizeAuthenticationFailure(error);
        }
        let issued;
        try {
          issued = await this.#config.sessions.exchangeWorkforceZero(credential, expected);
        } catch (error) {
          return normalizePostAuthenticationFailure(error, authenticateCurrent);
        }
        try {
          await authenticateCurrent();
          const child = issued.context;
          const credentialExpiry = Date.parse(issued.credential_expires_at);
          const sourceExpiry = Date.parse(source.credential_expires_at);
          const childSessionExpiry = Date.parse(child.expires_at);
          if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(issued.credential) || issued.credential.length > 16384 || child.audience !== "workforce" || child.session_id === source.context.session_id || child.company_id !== source.context.company_id || child.actor_id !== source.context.actor_id || child.device_id !== source.context.device_id || !Array.isArray(child.allowed_company_ids) || child.allowed_company_ids.length !== 1 || child.allowed_company_ids[0] !== child.company_id || !id(child.context_revision) || !Number.isSafeInteger(child.session_revision) || child.session_revision < 1 || !Number.isFinite(credentialExpiry) || !Number.isFinite(sourceExpiry) || !Number.isFinite(childSessionExpiry) || credentialExpiry > sourceExpiry || credentialExpiry > childSessionExpiry) return unavailable();
          const context = Object.freeze({
            schema: "titan.workforce-zero.session/v1",
            audience: "workforce",
            surface: "zero",
            actor_id: child.actor_id,
            company_id: child.company_id,
            company_ids: Object.freeze([child.company_id]),
            device_id: child.device_id,
            session_id: child.session_id,
            context_revision: child.context_revision,
            session_revision: child.session_revision,
            expires_at: childSessionExpiry
          });
          exchanged = Object.freeze({ credential: issued.credential, context });
        } catch (error) {
          if (safeErrorMessage(error) === "directadmin-session-rejected" || safeErrorMessage(error) === "authentication-denied") {
            return normalizeAuthenticationFailure(error);
          }
          return unavailable();
        }
        let result;
        try {
          result = await consume(exchanged.credential, exchanged.context);
        } catch (error) {
          try {
            await authenticateCurrent();
          } catch (verificationError) {
            return normalizeAuthenticationFailure(verificationError);
          }
          throw error;
        }
        try {
          await authenticateCurrent();
        } catch (error) {
          return normalizeAuthenticationFailure(error);
        }
        return result;
      };
      return Object.freeze({
        context: project(initial),
        revalidate,
        withWorkforceZeroSession,
        switchCompany: async (company_id) => {
          if (request.method !== "POST" || !id(company_id)) return fail();
          await revalidate();
          let issued;
          try {
            issued = await this.#config.sessions.switchCompany(credential, expected, company_id);
          } catch (error) {
            return normalizePostAuthenticationFailure(error, authenticateCurrent);
          }
          try {
            const current = check(await this.#config.sessions.authenticate(issued.credential, {
              company_id,
              device_id: expected.device_id,
              actor_id: expected.actor_id,
              context_revision: issued.context.context_revision
            }));
            const seconds = Math.min(300, Math.floor((Date.parse(current.context.expires_at) - Date.now()) / 1e3));
            if (!Number.isFinite(seconds) || seconds <= 0 || /[;\r\n]/.test(issued.credential)) return unavailable();
            return Object.freeze({ set_cookie: `${COOKIE}=${issued.credential}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${seconds}` });
          } catch (error) {
            const message = safeErrorMessage(error);
            if (message === "authentication-denied" || message === "directadmin-session-rejected") {
              return normalizeAuthenticationFailure(error);
            }
            if (message === "identity-registry-unavailable" || message === "directadmin-service-unavailable") return unavailable();
            return normalizePostAuthenticationFailure(error, authenticateCurrent);
          }
        },
        logout: async () => {
          if (request.method !== "POST") return fail();
          await revalidate();
          try {
            await this.#config.sessions.revoke(credential, expected);
          } catch (error) {
            return normalizePostAuthenticationFailure(error, authenticateCurrent);
          }
        }
      });
    } catch (error) {
      return normalizeAuthenticationFailure(error);
    }
  }
};
var DIRECTADMIN_RESPONSE_HEADERS = Object.freeze({
  "cache-control": "no-store",
  "content-type": "application/json; charset=utf-8",
  "x-content-type-options": "nosniff",
  "referrer-policy": "no-referrer",
  "content-security-policy": "default-src 'none'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'",
  "x-frame-options": "SAMEORIGIN"
});
var DIRECTADMIN_CLEAR_SESSION_COOKIE = `${COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`;

// packages/titan-platform/src/directadmin-gateway.ts
function assertDirectAdminProjection(value, company_id) {
  if (!value || typeof value !== "object") throw new Error("directadmin-invalid-projection");
  const projection = value;
  const data = projection.data;
  if (projection.company_id !== company_id || !data || typeof data !== "object" || Array.isArray(data) || data.company_id !== company_id || typeof data.schema !== "string" || !data.schema || typeof projection.source !== "string" || !projection.source.trim() || projection.source.length > 1024 || projection.freshness !== null && (typeof projection.freshness !== "string" || !Number.isFinite(Date.parse(projection.freshness))) || !Array.isArray(projection.evidence_refs) || projection.evidence_refs.length > 256 || projection.evidence_refs.some((ref) => typeof ref !== "string" || !ref.trim() || ref.length > 2048)) {
    throw new Error("directadmin-invalid-projection");
  }
}
var json = (status, body2, sessionCookie) => new Response(JSON.stringify(body2), {
  status,
  headers: { ...DIRECTADMIN_RESPONSE_HEADERS, ...sessionCookie ? { "set-cookie": sessionCookie } : {} }
});
function isTypedWorkforceDenial(error, expectedName, expectedCode) {
  try {
    if (!(error instanceof Error)) return false;
    const prototype = Object.getPrototypeOf(error);
    const constructor = prototype && Object.getOwnPropertyDescriptor(prototype, "constructor")?.value;
    const name = Object.getOwnPropertyDescriptor(error, "name");
    const code = Object.getOwnPropertyDescriptor(error, "code");
    const status = Object.getOwnPropertyDescriptor(error, "status");
    return Boolean(constructor?.name === expectedName && Object.getPrototypeOf(prototype) === Error.prototype && name && "value" in name && name.value === expectedName && code && "value" in code && code.value === expectedCode && status && "value" in status && status.value === 403);
  } catch {
    return false;
  }
}
function isUnsupportedWorkforceActionDenial(error) {
  return isTypedWorkforceDenial(error, "DirectAdminWorkforceActionDenied", "directadmin-workforce-action-unsupported");
}
function isWorkforceAuthorityDenial(error) {
  return isTypedWorkforceDenial(error, "DirectAdminWorkforceAuthorityDenied", "directadmin-workforce-authority-denied");
}
function bridgeFailure(error) {
  const kind = directAdminBridgeFailureKind(error);
  if (kind === "request-rejected") {
    return json(401, { error: "directadmin-session-rejected", read_only: true });
  }
  if (kind === "session-rejected") {
    return json(401, { error: "directadmin-session-rejected", read_only: true }, DIRECTADMIN_CLEAR_SESSION_COOKIE);
  }
  if (kind === "session-rejected-clear-cookie") {
    return json(401, { error: "directadmin-session-rejected", read_only: true }, DIRECTADMIN_CLEAR_SESSION_COOKIE);
  }
  if (kind === "session-binding-mismatch") {
    return json(409, { error: "directadmin-session-binding-mismatch", read_only: true });
  }
  return json(503, { error: "directadmin-context-or-owner-unavailable", read_only: true });
}
function bootstrapFailure(error) {
  const kind = directAdminBridgeFailureKind(error);
  if (kind === "request-rejected" || kind === "session-rejected") {
    return json(401, { error: "directadmin-session-rejected", read_only: true });
  }
  if (kind === "session-rejected-clear-cookie") {
    return json(401, { error: "directadmin-session-rejected", read_only: true }, DIRECTADMIN_CLEAR_SESSION_COOKIE);
  }
  if (kind === "unavailable-clear-cookie") {
    return json(503, { error: "directadmin-bootstrap-unavailable", read_only: true }, DIRECTADMIN_CLEAR_SESSION_COOKIE);
  }
  if (kind === "session-binding-mismatch") {
    return json(409, { error: "directadmin-session-binding-mismatch", read_only: true });
  }
  return json(503, { error: "directadmin-bootstrap-unavailable", read_only: true });
}
async function body(request) {
  if (request.headers.get("content-type")?.split(";")[0] !== "application/json" || request.headers.has("content-encoding")) throw new Error("invalid-body");
  const reader = request.body?.getReader();
  if (!reader) throw new Error("missing-body");
  const chunks = [];
  let length = 0;
  let timedOut = false;
  const deadline = setTimeout(() => {
    timedOut = true;
    void reader.cancel().catch(() => {
    });
  }, 5e3);
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      length += next.value.byteLength;
      if (length > 65536) throw new Error("body-too-large");
      chunks.push(next.value);
    }
    if (timedOut) throw new Error("body-timeout");
  } finally {
    clearTimeout(deadline);
    await reader.cancel();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  const parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("invalid-body");
  return parsed;
}
function createDirectAdminGateway(bridge, owners, bootstrapProvider) {
  let active = 0;
  const handle = async (request) => {
    let url;
    try {
      url = new URL(request.url);
    } catch {
      return json(400, { error: "invalid-route" });
    }
    if (url.search || url.hash) return json(400, { error: "invalid-route" });
    const path = url.pathname;
    if (path === "/v1/directadmin/bootstrap") {
      if (request.method !== "POST") return json(405, { error: "method-not-allowed" });
      try {
        const bootstrap = await bridge.bootstrapBrowserSession(request, async (proof) => {
          if (!bootstrapProvider) throw new Error("directadmin-service-unavailable");
          return bootstrapProvider.provide(proof);
        });
        return json(200, { csrf_token: bootstrap.csrf_token }, bootstrap.set_cookie);
      } catch (error) {
        return bootstrapFailure(error);
      }
    }
    let session;
    try {
      session = await bridge.authenticate(request);
    } catch (error) {
      return bridgeFailure(error);
    }
    try {
      if (request.method === "GET" && path === "/v1/directadmin/context") return json(200, session.context);
      if (request.method === "POST" && path === "/v1/directadmin/logout") {
        await session.logout();
        return json(200, { status: "reauthentication-required" }, DIRECTADMIN_CLEAR_SESSION_COOKIE);
      }
      if (request.method === "POST" && path === "/v1/directadmin/company") {
        const input = await body(request);
        if (typeof input.company_id !== "string" || Object.keys(input).length !== 1) return json(400, { error: "invalid-company-selection" });
        const switched = await session.switchCompany(input.company_id);
        return json(200, { status: "context-changed" }, switched.set_cookie);
      }
      const route = /^\/v1\/directadmin\/(titan_zero|titan_workforce|titan_operations|titan_web)\/(projection|intents)$/.exec(path);
      if (!route) return json(404, { error: "unknown-plugin-route" });
      const plugin = route[1];
      if (request.method === "GET" && route[2] === "projection") {
        const context = await session.revalidate();
        const projection = await owners.projection(plugin, context);
        assertDirectAdminProjection(projection, context.company_id);
        await session.revalidate();
        return json(200, { context, projection });
      }
      if (request.method === "POST" && route[2] === "intents") {
        const input = await body(request);
        const context = await session.revalidate();
        const contextRevisionMatches = typeof input.context_revision === "string" && await matchesDirectAdminContextRevision(input.context_revision, context.context_revision);
        if (input.company_id !== context.company_id || input.actor_id !== context.actor_id || !contextRevisionMatches || !["capability_id", "operation_id", "correlation_id"].every((k) => typeof input[k] === "string" && /^[A-Za-z0-9:._-]{1,200}$/.test(input[k])) || !input.input || typeof input.input !== "object" || Array.isArray(input.input) || Object.keys(input).some((k) => !["company_id", "actor_id", "context_revision", "capability_id", "operation_id", "correlation_id", "input"].includes(k))) {
          return json(409, { error: "intent-context-mismatch" });
        }
        const intent = Object.freeze({
          company_id: context.company_id,
          actor_id: context.actor_id,
          capability_id: input.capability_id,
          operation_id: input.operation_id,
          correlation_id: input.correlation_id,
          input: input.input
        });
        const withWorkforceZeroSession = plugin === "titan_zero" || plugin === "titan_workforce" ? session.withWorkforceZeroSession : async () => {
          throw new Error("directadmin-workforce-zero-unavailable");
        };
        const receipt = await owners.requestIntent(
          plugin,
          intent,
          context,
          session.revalidate,
          withWorkforceZeroSession,
          { signal: request.signal }
        );
        if (!receipt || typeof receipt.receipt_id !== "string" || receipt.receipt_id.length > 200 || !/^[A-Za-z0-9:._-]+$/.test(receipt.receipt_id) || /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(receipt.receipt_id)) {
          throw new Error("directadmin-owner-receipt-invalid");
        }
        return json(202, { status: "REQUESTED", receipt_id: receipt.receipt_id, correlation_id: intent.correlation_id });
      }
      return json(405, { error: "method-not-allowed" });
    } catch (error) {
      if (isUnsupportedWorkforceActionDenial(error)) {
        return json(403, { error: "directadmin-workforce-action-unsupported", read_only: true });
      }
      if (isWorkforceAuthorityDenial(error)) {
        return json(403, { error: "directadmin-workforce-authority-denied", read_only: true });
      }
      return bridgeFailure(error);
    }
  };
  return async (request) => {
    if (active >= 32) return json(503, { error: "directadmin-busy", read_only: true });
    active++;
    try {
      return await handle(request);
    } finally {
      active--;
    }
  };
}

// packages/titan-platform/src/directadmin-workforce-skills.ts
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var id2 = (value) => typeof value === "string" && value.length > 0 && value === value.trim() && !/[\u0000-\u001f\u007f]/u.test(value);
var finite = (value) => typeof value === "number" && Number.isFinite(value);
var exactKeys = (value, keys) => Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
var numericSummary = (value, keys) => object(value) && exactKeys(value, keys) && Object.values(value).every((count) => Number.isSafeInteger(count) && count >= 0);
var flagsAreSafe = (value) => value.read_only === true && value.capability_presence_confers_authority === false && value.verification_confers_authority === false && value.assignment_decision === false && value.routing_decision === false && value.entitlement_decision === false && value.execution_permitted === false && value.grants_authority === false;
function assertDirectAdminWorkforceSkillsProjection(value, expected) {
  const fail2 = () => {
    throw new Error("directadmin-workforce-skills-projection-invalid");
  };
  if (!object(value)) fail2();
  const envelope = value;
  if (envelope.schema !== "titan.directadmin.workforce-skills.v1" || envelope.company_id !== expected.company_id || envelope.context_revision !== expected.context_revision || !flagsAreSafe(envelope) || Object.keys(envelope).some((key) => ![
    "schema",
    "company_id",
    "context_revision",
    "read_only",
    "capability_presence_confers_authority",
    "verification_confers_authority",
    "assignment_decision",
    "routing_decision",
    "entitlement_decision",
    "execution_permitted",
    "grants_authority",
    "status",
    "reason",
    "source",
    "freshness",
    "source_revision",
    "evidence_refs",
    "projection"
  ].includes(key))) fail2();
  if (envelope.status === "unavailable") {
    if (!exactKeys(envelope, [
      "schema",
      "company_id",
      "context_revision",
      "read_only",
      "capability_presence_confers_authority",
      "verification_confers_authority",
      "assignment_decision",
      "routing_decision",
      "entitlement_decision",
      "execution_permitted",
      "grants_authority",
      "status",
      "reason",
      "source",
      "freshness",
      "source_revision",
      "evidence_refs"
    ]) || envelope.reason !== "canonical-skill-projection-unavailable" || envelope.source !== null || envelope.freshness !== null || envelope.source_revision !== null || !Array.isArray(envelope.evidence_refs) || envelope.evidence_refs.length !== 0 || Object.hasOwn(envelope, "projection")) fail2();
    return;
  }
  if (envelope.status !== "available" || envelope.source !== "canonical-workforce-skill-capability-registry" || !(envelope.freshness === null || typeof envelope.freshness === "string" && Number.isFinite(Date.parse(envelope.freshness))) || !(envelope.source_revision === null || Number.isSafeInteger(envelope.source_revision) && envelope.source_revision >= 0) || !Array.isArray(envelope.evidence_refs) || envelope.evidence_refs.some((ref) => !id2(ref)) || !object(envelope.projection)) fail2();
  const proof = envelope.projection;
  if (!exactKeys(envelope, [
    "schema",
    "company_id",
    "context_revision",
    "read_only",
    "capability_presence_confers_authority",
    "verification_confers_authority",
    "assignment_decision",
    "routing_decision",
    "entitlement_decision",
    "execution_permitted",
    "grants_authority",
    "status",
    "source",
    "freshness",
    "source_revision",
    "evidence_refs",
    "projection"
  ]) || !exactKeys(proof, [
    "schema",
    "company_id",
    "workers",
    "skill_proofs",
    "summary",
    "read_only",
    "derived",
    "performance_is_context_only",
    "routing_decision",
    "entitlement_decision",
    "assignment_decision",
    "automatic_execution",
    "execution_permitted",
    "grants_authority"
  ])) fail2();
  const roster = new Set(expected.worker_ids);
  if (proof.schema !== "titan.workforce.evidence-backed-skill-proof.v1" || proof.company_id !== expected.company_id || proof.read_only !== true || proof.derived !== true || proof.performance_is_context_only !== true || proof.routing_decision !== false || proof.entitlement_decision !== false || proof.assignment_decision !== false || proof.automatic_execution !== false || proof.execution_permitted !== false || proof.grants_authority !== false || !Array.isArray(proof.workers) || !Array.isArray(proof.skill_proofs) || !numericSummary(proof.summary, [
    "worker_count",
    "skill_proof_count",
    "verified_skill_proofs",
    "evidenced_skill_proofs",
    "unverified_skill_proofs",
    "invalid_skill_proofs",
    "requirement_gaps",
    "workers_with_contextual_performance"
  ])) fail2();
  const seenWorkers = /* @__PURE__ */ new Set();
  const workerSkillBindings = /* @__PURE__ */ new Set();
  for (const workerValue of proof.workers) {
    if (!object(workerValue)) fail2();
    const worker = workerValue;
    if (!id2(worker.worker_id) || !roster.has(worker.worker_id) || seenWorkers.has(worker.worker_id) || !exactKeys(worker, ["worker_id", "skills", "summary", "worker_identity_confers_authority", "grants_authority"]) || !Array.isArray(worker.skills) || !numericSummary(worker.summary, ["skill_count", "verified", "evidenced", "unverified", "expired_or_revoked", "requirement_gaps"]) || worker.worker_identity_confers_authority !== false || worker.grants_authority !== false) fail2();
    seenWorkers.add(worker.worker_id);
    for (const skill of worker.skills) {
      validateSkill(skill, worker.worker_id);
      const key = `${skill.worker_id}\0${skill.capability_id}`;
      if (workerSkillBindings.has(key)) fail2();
      workerSkillBindings.add(key);
    }
  }
  const seenSkills = /* @__PURE__ */ new Set();
  for (const skill of proof.skill_proofs) {
    validateSkill(skill);
    const key = `${skill.worker_id}\0${skill.capability_id}`;
    if (seenSkills.has(key) || !workerSkillBindings.has(key)) fail2();
    seenSkills.add(key);
  }
  if (seenSkills.size !== workerSkillBindings.size || proof.skill_proofs.some((skill) => !roster.has(skill.worker_id)) || envelope.evidence_refs.length !== new Set(envelope.evidence_refs).size || envelope.evidence_refs.some((ref) => !proof.skill_proofs.some((skill) => skill.evidence_refs.includes(ref))) || [...new Set(proof.skill_proofs.flatMap((skill) => skill.evidence_refs))].some((ref) => !envelope.evidence_refs.includes(ref))) fail2();
  function validateSkill(skill, expectedWorker) {
    if (!object(skill)) fail2();
    const candidate = skill;
    if (!exactKeys(candidate, [
      "worker_id",
      "capability_id",
      "proficiency",
      "proficiency_level",
      "verification_state",
      "proof_state",
      "proof_strength",
      "evidence_count",
      "evidence_refs",
      "contextual_performance_support",
      "contextual_performance_is_not_capability_verification",
      "meets_registry_requirement",
      "required_min_proficiency",
      "require_verified",
      "expired_or_revoked",
      "capability_presence_confers_authority",
      "verification_confers_authority",
      "performance_confers_authority",
      "grants_authority"
    ]) || !id2(candidate.worker_id) || !roster.has(candidate.worker_id) || expectedWorker !== void 0 && candidate.worker_id !== expectedWorker || !id2(candidate.capability_id) || !finite(candidate.proficiency) || candidate.proficiency < 0 || candidate.proficiency > 5 || !id2(candidate.proficiency_level) || !id2(candidate.verification_state) || !["verified", "evidenced", "unverified", "expired", "revoked"].includes(candidate.proof_state) || !finite(candidate.proof_strength) || candidate.proof_strength < 0 || candidate.proof_strength > 1 || !Number.isSafeInteger(candidate.evidence_count) || candidate.evidence_count < 0 || !Array.isArray(candidate.evidence_refs) || candidate.evidence_refs.some((ref) => !id2(ref)) || candidate.evidence_count !== new Set(candidate.evidence_refs).size || candidate.evidence_refs.length !== new Set(candidate.evidence_refs).size || candidate.contextual_performance_is_not_capability_verification !== true || !(candidate.meets_registry_requirement === null || typeof candidate.meets_registry_requirement === "boolean") || !(candidate.required_min_proficiency === null || finite(candidate.required_min_proficiency) && candidate.required_min_proficiency >= 0 && candidate.required_min_proficiency <= 5) || !(candidate.require_verified === null || typeof candidate.require_verified === "boolean") || typeof candidate.expired_or_revoked !== "boolean" || candidate.capability_presence_confers_authority !== false || candidate.verification_confers_authority !== false || candidate.performance_confers_authority !== false || candidate.grants_authority !== false) fail2();
    if (candidate.contextual_performance_support !== null && (!object(candidate.contextual_performance_support) || !exactKeys(candidate.contextual_performance_support, ["outcome_count", "evidence_backed_count", "performance_score", "confidence"]) || !Number.isSafeInteger(candidate.contextual_performance_support.outcome_count) || candidate.contextual_performance_support.outcome_count < 0 || !Number.isSafeInteger(candidate.contextual_performance_support.evidence_backed_count) || candidate.contextual_performance_support.evidence_backed_count < 0 || !(candidate.contextual_performance_support.performance_score === null || finite(candidate.contextual_performance_support.performance_score)) || !finite(candidate.contextual_performance_support.confidence) || candidate.contextual_performance_support.confidence < 0 || candidate.contextual_performance_support.confidence > 1)) fail2();
  }
}

// packages/titan-platform/src/directadmin-cockpit.ts
var DirectAdminCockpitSession = class {
  /** The callback reads a trusted HTML bootstrap nonce. A successful bootstrap
   * response replaces it with the session CSRF token held only in this object. */
  constructor(bootstrapNonce, fetcher = (input, init) => fetch(input, init), channel) {
    this.bootstrapNonce = bootstrapNonce;
    this.fetcher = fetcher;
    this.#channel = channel ?? (typeof window !== "undefined" && typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("titan-directadmin-context") : void 0);
    if (this.#channel) this.#channel.onmessage = () => this.invalidate(false, true);
  }
  bootstrapNonce;
  fetcher;
  #context = null;
  #csrfToken = null;
  #usedBootstrapNonces = /* @__PURE__ */ new Set();
  #connecting = null;
  #epoch = 0;
  #listeners = /* @__PURE__ */ new Set();
  #expiry;
  #channel;
  #disposed = false;
  subscribe(listener) {
    this.#listeners.add(listener);
    return () => {
      this.#listeners.delete(listener);
    };
  }
  invalidate(broadcast = true, retainCsrf = true) {
    this.#epoch++;
    this.#context = null;
    if (!retainCsrf) this.#csrfToken = null;
    clearTimeout(this.#expiry);
    for (const listener of this.#listeners) {
      try {
        listener();
      } catch {
      }
    }
    if (broadcast) this.#channel?.postMessage("invalidate");
  }
  dispose() {
    this.#disposed = true;
    this.invalidate(true, false);
    this.#channel?.close();
    this.#listeners.clear();
  }
  async send(path, body2) {
    if (this.#disposed) throw new Error("directadmin-session-disposed");
    const epoch = this.#epoch;
    const csrf = this.#csrfToken;
    if (!csrf || !/^[A-Za-z0-9_-]{43,128}$/.test(csrf)) throw new Error("directadmin-session-not-initialized");
    const response = await this.fetcher(path, {
      method: body2 === void 0 ? "GET" : "POST",
      credentials: "same-origin",
      cache: "no-store",
      redirect: "error",
      referrerPolicy: "same-origin",
      signal: AbortSignal.timeout(1e4),
      headers: {
        Accept: "application/json",
        "X-Titan-CSRF": csrf,
        ...body2 === void 0 ? {} : { "Content-Type": "application/json" }
      },
      ...body2 === void 0 ? {} : { body: JSON.stringify(body2) }
    });
    if (epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    if (!response.ok) {
      if ([401, 409].includes(response.status)) this.invalidate(true, false);
      throw new Error(`directadmin-http-${response.status}`);
    }
    const result = await response.json();
    if (epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    return result;
  }
  accept(value, allowContextChange = false) {
    if (value?.schema !== "titan.directadmin.session/v1" || value.authority !== "not-carried" || typeof value.actor_id !== "string" || !value.actor_id || typeof value.company_id !== "string" || !value.company_id || !Array.isArray(value.company_ids) || value.company_ids.length !== 1 || value.company_ids[0] !== value.company_id || typeof value.context_revision !== "string" || !value.context_revision || !Number.isSafeInteger(value.session_revision) || value.session_revision < 1 || !["admin", "reseller", "user"].includes(value.da_role) || !Number.isFinite(value.expires_at) || value.expires_at <= Date.now()) {
      this.invalidate(true, false);
      throw new Error("directadmin-invalid-context");
    }
    if (this.#context && (this.#context.company_id !== value.company_id || this.#context.actor_id !== value.actor_id || this.#context.context_revision !== value.context_revision || this.#context.session_revision !== value.session_revision)) {
      this.invalidate(true, true);
      if (!allowContextChange) throw new Error("directadmin-context-invalidated");
    }
    this.#context = Object.freeze({ ...value, company_ids: Object.freeze([...value.company_ids]) });
    clearTimeout(this.#expiry);
    this.#expiry = setTimeout(() => this.invalidate(true, false), Math.min(value.expires_at - Date.now(), 2147483647));
    return this.#context;
  }
  async connect() {
    if (this.#disposed) throw new Error("directadmin-session-disposed");
    if (this.#connecting) return this.#connecting;
    const operation = this.connectCurrentSession();
    this.#connecting = operation;
    try {
      return await operation;
    } finally {
      if (this.#connecting === operation) this.#connecting = null;
    }
  }
  async connectCurrentSession() {
    if (!this.#csrfToken) {
      let nonce;
      try {
        nonce = this.bootstrapNonce();
      } catch {
        throw new Error("directadmin-bootstrap-nonce-unavailable");
      }
      if (typeof nonce !== "string" || !/^[A-Za-z0-9_-]{43,128}$/.test(nonce)) {
        throw new Error("directadmin-bootstrap-nonce-unavailable");
      }
      return this.bootstrapAndConnect(nonce);
    }
    try {
      const epoch = this.#epoch;
      const result = await this.send("/v1/directadmin/context");
      if (this.#disposed || epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
      return this.accept(result, true);
    } catch (error) {
      if (this.#disposed) {
        if (error instanceof Error && error.message === "directadmin-context-invalidated") throw error;
        throw new Error("directadmin-session-disposed");
      }
      if (!error || typeof error !== "object" || !["directadmin-http-401", "directadmin-http-409"].includes(String(error.message))) throw error;
      let nonce;
      try {
        nonce = this.bootstrapNonce();
      } catch {
        throw new Error("directadmin-bootstrap-nonce-unavailable");
      }
      if (typeof nonce !== "string" || !/^[A-Za-z0-9_-]{43,128}$/.test(nonce)) {
        throw new Error("directadmin-bootstrap-nonce-unavailable");
      }
      return this.bootstrapAndConnect(nonce);
    }
  }
  async bootstrapAndConnect(nonce) {
    if (this.#usedBootstrapNonces.has(nonce)) throw new Error("directadmin-bootstrap-nonce-reused");
    this.#usedBootstrapNonces.add(nonce);
    this.#csrfToken = null;
    const epoch = this.#epoch;
    let response;
    try {
      response = await this.fetcher("/v1/directadmin/bootstrap", {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        redirect: "error",
        referrerPolicy: "same-origin",
        signal: AbortSignal.timeout(1e4),
        headers: { Accept: "application/json", "X-Titan-DA-Bootstrap-CSRF": nonce },
        body: ""
      });
    } catch {
      throw new Error("directadmin-bootstrap-unavailable");
    }
    if (this.#disposed || epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    if (!response.ok) {
      if (response.status === 401) throw new Error("directadmin-session-rejected");
      if (response.status === 409) throw new Error("directadmin-session-binding-mismatch");
      if ([403].includes(response.status)) throw new Error("directadmin-bootstrap-rejected");
      throw new Error("directadmin-bootstrap-unavailable");
    }
    let value;
    try {
      value = await response.json();
    } catch {
      throw new Error("directadmin-bootstrap-response-invalid");
    }
    if (this.#disposed || epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== 1 || !Object.hasOwn(value, "csrf_token") || typeof value.csrf_token !== "string" || !/^[A-Za-z0-9_-]{43,128}$/.test(value.csrf_token)) {
      throw new Error("directadmin-bootstrap-response-invalid");
    }
    this.#csrfToken = value.csrf_token;
    const resultEpoch = this.#epoch;
    const result = await this.send("/v1/directadmin/context");
    if (this.#disposed || resultEpoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    return this.accept(result, true);
  }
  async projection(plugin) {
    if (!["titan_zero", "titan_workforce", "titan_operations", "titan_web"].includes(plugin)) throw new Error("unknown-plugin");
    const epoch = this.#epoch;
    const result = await this.send(`/v1/directadmin/${plugin}/projection`);
    if (this.#disposed || epoch !== this.#epoch) throw new Error("directadmin-context-invalidated");
    const context = this.accept(result?.context);
    if (epoch !== this.#epoch) throw new Error("directadmin-projection-invalidated");
    assertDirectAdminProjection(result.projection, context.company_id);
    if (plugin === "titan_workforce") {
      const data = result.projection.data;
      if (data?.discovery && Object.hasOwn(data.discovery, "skills")) {
        const workerIds = Array.isArray(data.discovery.workers) ? data.discovery.workers.flatMap((worker) => worker && typeof worker === "object" && typeof worker.worker_id === "string" ? [worker.worker_id] : []) : [];
        assertDirectAdminWorkforceSkillsProjection(data.discovery.skills, {
          company_id: context.company_id,
          context_revision: context.context_revision,
          worker_ids: workerIds
        });
      }
    }
    return result.projection;
  }
  async intent(plugin, intent) {
    const context = this.#context;
    const epoch = this.#epoch;
    if (!["titan_zero", "titan_workforce", "titan_operations", "titan_web"].includes(plugin) || !context || context.expires_at <= Date.now() || intent.company_id !== context.company_id || intent.actor_id !== context.actor_id) {
      throw new Error("directadmin-intent-context-mismatch");
    }
    const context_revision = await directAdminContextRevisionAssertion(context.context_revision);
    if (this.#disposed || epoch !== this.#epoch || this.#context !== context) throw new Error("directadmin-context-invalidated");
    return this.send(`/v1/directadmin/${plugin}/intents`, { ...intent, context_revision });
  }
  async switchCompany(company_id) {
    this.invalidate(true, true);
    try {
      await this.send("/v1/directadmin/company", { company_id });
    } finally {
      this.invalidate(true, true);
    }
  }
  async logout() {
    this.invalidate(true, true);
    try {
      await this.send("/v1/directadmin/logout", {});
    } finally {
      this.invalidate(true, false);
    }
  }
};
function mountDirectAdminProjection(session, input) {
  const doc = input.root.ownerDocument;
  const heading = doc.createElement("h2");
  heading.textContent = input.title;
  const status = doc.createElement("p");
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  const evidence = doc.createElement("pre");
  const refresh = doc.createElement("button");
  refresh.type = "button";
  refresh.textContent = "Refresh";
  input.root.replaceChildren(heading, status, evidence, refresh);
  let generation = 0;
  const state = (name, text) => {
    input.root.setAttribute("data-state", name);
    status.textContent = text;
  };
  const clear = () => {
    generation++;
    state("read-only", "Read-only \u2014 authenticate current company context");
    evidence.textContent = "";
  };
  const unsubscribe = session.subscribe(clear);
  const load = async () => {
    const current = ++generation;
    state("loading", "Loading");
    evidence.textContent = "";
    try {
      const projection = await session.projection(input.plugin_id);
      if (current !== generation) return;
      if (projection.data.schema !== input.expected_schema) {
        state("incompatible", "Read-only \u2014 incompatible projection version");
        return;
      }
      const age = projection.freshness === null ? null : Date.now() - Date.parse(projection.freshness);
      if (age === null || age < -6e4) state("unknown", "Read-only \u2014 projection freshness unknown");
      else if (age > 3e5) state("stale", "Read-only \u2014 projection is stale");
      else state("ready", input.summarize(projection));
      evidence.textContent = `Source: ${projection.source}
Freshness: ${projection.freshness ?? "unknown"}
Evidence: ${projection.evidence_refs.join(", ") || "unavailable"}`;
    } catch {
      if (current === generation) {
        state("unavailable", "Read-only \u2014 projection unavailable");
        evidence.textContent = "";
      }
    }
  };
  refresh.addEventListener("click", load);
  clear();
  return { refresh: load, dispose: () => {
    clear();
    unsubscribe();
    refresh.removeEventListener("click", load);
    input.root.replaceChildren();
  } };
}

// packages/titan-platform/src/directadmin-plugin.ts
var ID = /^[a-z][a-z0-9_-]{1,62}$/;
var VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;
var DIRECTADMIN_SDK_COMPATIBILITY_VERSION = "1.0.0";
var ROLE_PATH = {
  admin: "admin/index.html",
  reseller: "reseller/index.html",
  user: "user/index.html"
};
var REQUIRED_FILES = ["plugin.conf", "README.md", "AGENTS.md", "scripts/install.sh", "scripts/uninstall.sh"];
function safeRelativePath(path) {
  return path.length > 0 && !path.startsWith("/") && !path.includes("\\") && !path.split("/").some((part) => part === "" || part === "." || part === "..");
}
function validateDirectAdminPluginPackage(input) {
  const errors = [];
  const plugin_id = String(input?.plugin_id ?? "").trim();
  const version = String(input?.version ?? "").trim();
  if (!ID.test(plugin_id)) errors.push("invalid-plugin-id");
  if (!VERSION.test(version)) errors.push("invalid-plugin-version");
  if (input?.archive_filename !== `${plugin_id}.tar.gz`) errors.push("archive-filename-must-match-plugin-id");
  const manifest = Object.fromEntries((input?.manifest_content ?? "").split(/\r?\n/).filter(Boolean).map((line) => {
    const separator = line.indexOf("=");
    return separator > 0 ? [line.slice(0, separator).trim(), line.slice(separator + 1).trim()] : ["", ""];
  }));
  if (!manifest.version || manifest.version !== version) errors.push("manifest-version-mismatch");
  const files = new Set(input?.files ?? []);
  for (const required of REQUIRED_FILES) if (!files.has(required)) errors.push(`missing-file:${required}`);
  for (const [role, expected] of Object.entries(ROLE_PATH)) {
    const path = input?.role_entrypoints?.[role];
    if (!path || !files.has(path)) errors.push(`missing-role-entrypoint:${role}`);
    else if (path !== expected) errors.push(`noncanonical-role-entrypoint:${role}`);
    if (path && !(input?.executable_files ?? []).includes(path)) errors.push(`role-entrypoint-not-executable:${role}`);
  }
  for (const file of ["scripts/install.sh", "scripts/uninstall.sh"]) {
    if (files.has(file) && !(input?.executable_files ?? []).includes(file)) errors.push(`lifecycle-script-not-executable:${file}`);
  }
  for (const path of files) if (!safeRelativePath(path)) errors.push(`unsafe-file-path:${path}`);
  for (const hook of input?.hooks ?? []) {
    if (!safeRelativePath(hook) || !hook.startsWith("hooks/")) errors.push(`unsafe-hook-path:${hook}`);
  }
  return Object.freeze({ valid: errors.length === 0, errors: Object.freeze([...new Set(errors)]), plugin_id, version });
}
function assertPluginCanBeInstalled(result) {
  if (!result.valid) throw new Error(`plugin-validation-failed:${result.errors.join(",")}`);
  return true;
}
var nonEmpty = (value) => typeof value === "string" && value.trim().length > 0;
async function resolveDirectAdminTitanContext(session, resolveIdentity, now = Date.now()) {
  if (!session?.authenticated) return { status: "read-only", reason: "unauthenticated" };
  if (![session.session_id, session.account_id].every(nonEmpty) || !["admin", "reseller", "user"].includes(session.role)) {
    return { status: "read-only", reason: "invalid-session" };
  }
  let identity;
  try {
    identity = await resolveIdentity(session);
  } catch {
    return { status: "read-only", reason: "identity-service-unavailable" };
  }
  if (!identity || ![identity.actor_id, identity.active_company_id, identity.session_revision].every(nonEmpty)) {
    return { status: "read-only", reason: "unresolved-identity" };
  }
  const companies = [...new Set(identity.allowed_company_ids ?? [])];
  if (!companies.length || !companies.includes(identity.active_company_id) || companies.some((id3) => !nonEmpty(id3)) || !Number.isFinite(identity.expires_at)) return { status: "read-only", reason: "invalid-company-context" };
  if (identity.expires_at <= now) return { status: "read-only", reason: "expired-context" };
  return {
    status: "resolved",
    context: Object.freeze({
      schema: "titan.directadmin.context/v1",
      actor_id: identity.actor_id,
      company_id: identity.active_company_id,
      allowed_company_ids: Object.freeze([identity.active_company_id]),
      entitlements: Object.freeze([...identity.entitlements ?? []]),
      session_revision: identity.session_revision,
      authority_revision: nonEmpty(identity.authority_revision) ? identity.authority_revision : null,
      expires_at: identity.expires_at,
      da_role: session.role,
      authority: "not-carried"
    })
  };
}
function validateDirectAdminCompanyContext(context, requestedCompanyId, sessionRevision, now = Date.now()) {
  return context.schema === "titan.directadmin.context/v1" && context.authority === "not-carried" && context.company_id === requestedCompanyId && context.allowed_company_ids.includes(requestedCompanyId) && context.session_revision === sessionRevision && context.expires_at > now;
}
var DirectAdminTitanApiClient = class {
  constructor(context, fetcher = (input, init) => fetch(input, init), requestId = () => crypto.randomUUID()) {
    this.context = context;
    this.fetcher = fetcher;
    this.requestId = requestId;
  }
  context;
  fetcher;
  requestId;
  async projection(path, now = Date.now()) {
    return this.send("GET", path, void 0, now);
  }
  async submitIntent(path, intent, now = Date.now()) {
    if (intent.company_id !== this.context.company_id || intent.actor_id !== this.context.actor_id || !nonEmpty(intent.capability_id) || !nonEmpty(intent.operation_id) || !nonEmpty(intent.correlation_id)) {
      throw new Error("directadmin-intent-context-mismatch");
    }
    return this.send("POST", path, intent, now);
  }
  async send(method, path, body2, now = Date.now()) {
    if (!validateDirectAdminCompanyContext(this.context, this.context.company_id, this.context.session_revision, now)) {
      throw new Error("directadmin-context-expired-or-invalid");
    }
    if (!path.startsWith("/v1/") || path.startsWith("//") || path.includes("\\") || /[?#]/.test(path) || path.split("/").some((part) => part === ".." || part === ".")) throw new Error("invalid-titan-api-path");
    const headers = {
      Accept: "application/json",
      "X-Titan-Request-ID": this.requestId(),
      "X-Titan-Correlation-ID": body2 && typeof body2 === "object" && "correlation_id" in body2 ? String(body2.correlation_id) : this.requestId(),
      "X-Titan-Company-ID": this.context.company_id,
      "X-Titan-Actor-ID": this.context.actor_id,
      "X-Titan-Context-Revision": this.context.session_revision
    };
    if (body2 !== void 0) headers["Content-Type"] = "application/json";
    const response = await this.fetcher(path, {
      method,
      credentials: "same-origin",
      redirect: "error",
      cache: "no-store",
      headers,
      ...body2 === void 0 ? {} : { body: JSON.stringify(body2) }
    });
    if (!response.ok) throw new Error(`titan-api-http-${response.status}`);
    return await response.json();
  }
};
var SENSITIVE_KEY = /(?:authorization|token|cookie|csrf|session.?id|secret|password|credential|private.?key|api.?key)/i;
var SENSITIVE_VALUE = /\bBearer\s+[A-Za-z0-9._~+/=-]+|\b(?:proxy-)?authorization\s*[:=]\s*Basic\s+[A-Za-z0-9._~+/=-]+|\b(?:x-titan-csrf|csrf(?:[-_]?token)?)\s*[:=]\s*(?:"[^"\r\n]*"|'[^'\r\n]*'|[^\s,;]+)|-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/gi;
function redactDirectAdminDiagnostics(value) {
  if (Array.isArray(value)) return value.map(redactDirectAdminDiagnostics);
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, SENSITIVE_KEY.test(key) ? "[REDACTED]" : redactDirectAdminDiagnostics(child)]));
  }
  return typeof value === "string" ? value.replace(SENSITIVE_VALUE, "[REDACTED]").replace(/\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{20,}\b/g, "[REDACTED]") : value;
}
function validRoute(route) {
  return route.startsWith("/") && !route.startsWith("//") && !route.includes("\\") && !/[?#]/.test(route) && route.split("/").every((part) => part !== ".." && part !== ".");
}
var DirectAdminContributionRegistry = class {
  #items = /* @__PURE__ */ new Map();
  #degraded = /* @__PURE__ */ new Map();
  #supportedSdkMajor;
  constructor(sdkCompatibilityVersion = DIRECTADMIN_SDK_COMPATIBILITY_VERSION) {
    const version = VERSION.exec(sdkCompatibilityVersion);
    if (!version) throw new Error("invalid-sdk-compatibility-version");
    this.#supportedSdkMajor = version[1];
  }
  register(contribution) {
    const pluginId = String(contribution?.plugin_id ?? "");
    try {
      const compatibility = VERSION.exec(contribution.sdk_compatibility);
      if (!ID.test(pluginId) || !VERSION.test(contribution.plugin_version) || !compatibility) {
        throw new Error("invalid-plugin-version-or-id");
      }
      if (compatibility[1] !== this.#supportedSdkMajor) {
        throw new Error(`sdk-compatibility-mismatch:required-major-${compatibility[1]}:supported-major-${this.#supportedSdkMajor}`);
      }
      if (this.#items.has(pluginId)) throw new Error("duplicate-plugin-contribution");
      const navIds = /* @__PURE__ */ new Set();
      for (const item of contribution.navigation) {
        if (!nonEmpty(item.id) || !nonEmpty(item.label) || !validRoute(item.route) || navIds.has(item.id) || !item.roles.length || item.roles.some((role) => !["admin", "reseller", "user"].includes(role))) {
          throw new Error("invalid-navigation-contribution");
        }
        navIds.add(item.id);
      }
      const widgetIds = /* @__PURE__ */ new Set();
      for (const widget of contribution.widgets) {
        if (!nonEmpty(widget.id) || widgetIds.has(widget.id) || !nonEmpty(widget.title) || !nonEmpty(widget.source) || !["loading", "ready", "empty", "stale", "degraded", "unavailable", "permission-denied"].includes(widget.status)) {
          throw new Error("invalid-widget-contribution");
        }
        if (widget.deep_link !== null && !validRoute(widget.deep_link)) throw new Error("invalid-widget-deep-link");
        widgetIds.add(widget.id);
      }
      this.#items.set(pluginId, structuredClone(contribution));
      this.#degraded.delete(pluginId);
    } catch (error) {
      this.#degraded.set(pluginId || "unknown", error instanceof Error ? error.message : "invalid-contribution");
    }
  }
  snapshot() {
    return Object.freeze({
      contributions: Object.freeze([...this.#items.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, item]) => item)),
      degraded_plugins: Object.freeze(Object.fromEntries([...this.#degraded.entries()].sort(([a], [b]) => a.localeCompare(b))))
    });
  }
};
export {
  DIRECTADMIN_CLEAR_SESSION_COOKIE,
  DIRECTADMIN_RESPONSE_HEADERS,
  DIRECTADMIN_SDK_COMPATIBILITY_VERSION,
  DirectAdminCockpitSession,
  DirectAdminContributionRegistry,
  DirectAdminSessionBridge,
  DirectAdminTitanApiClient,
  assertDirectAdminProjection,
  assertDirectAdminWorkforceSkillsProjection,
  assertPluginCanBeInstalled,
  createDirectAdminGateway,
  directAdminBridgeFailureKind,
  directAdminContextRevisionAssertion,
  matchesDirectAdminContextRevision,
  mountDirectAdminProjection,
  redactDirectAdminDiagnostics,
  resolveDirectAdminTitanContext,
  validateDirectAdminCompanyContext,
  validateDirectAdminPluginPackage
};
